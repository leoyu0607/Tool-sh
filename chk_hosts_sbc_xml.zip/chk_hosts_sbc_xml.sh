#/bin/bash

#宣告IPv4的格式
ipv4_pattern="^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"

#檔案備份
backupdatetime=backup_$(date +%Y%m%d_%H%M%S)
dos2unix /home/sbc/cin/xmlwoods/sbc.xml
su - sbc -c "cp -rf /home/sbc/cin/xmlwoods/sbc.xml /home/sbc/cin/xmlwoods/sbc.xml_${backupdatetime}"
su - acdweb -c "cp -rf /home/acdweb/cin/xmlwoods/WebCall.xml /home/acdweb/cin/xmlwoods/WebCall.xml_${backupdatetime}  "
	# 檢查 /etc/hosts 檔案是否存在
	if [ ! -f /etc/hosts ]; then
		echo "找不到 /etc/hosts 檔案。請確認檔案是否存在。"
		exit 1
	fi
cp -rfp /etc/hosts /etc/hosts_${backupdatetime}

	if [ ! -e /home/setup/installed.txt ]; then
		mkdir -p /home/setup
		touch /home/setup/installed.txt
	fi


## =======================================修改sbx.xml檔案-start=======================================
## -------------------------------------------sbc內網-------------------------------------------------
# 提示用户输入sbc內網IP
read -p "請输入sbc的內網地址: " sbc_internal_ip
# 檢查使用者是否輸入了IP地址並驗證是否為IPv4格式
	if [[ -z "$sbc_internal_ip" || ! $sbc_internal_ip =~ $ipv4_pattern ]]; then
		echo "未提供有效的IPv4格式內部IP地址。"
		exit 1
	fi
	echo "開始修改sbc.xml中的sbc內部IP"
	# 將預設多出的msPublicIp一組移除
	awk '/\<msPublicIp\>/ {if (count == 0) {print; count = 1}} !/\<msPublicIp\>/' /home/sbc/cin/xmlwoods/sbc.xml_${backupdatetime} > /home/sbc/cin/xmlwoods/sbc.xml
	# 使用sed命令將sbc.xml文件中的<ipAddress>替換為SBC的內部IP地址
	sed -i "s/<ipAddress>.*<\/ipAddress>/<ipAddress>${sbc_internal_ip}<\/ipAddress>/" /home/sbc/cin/xmlwoods/sbc.xml
	# 使用sed命令將sbc.xml文件中的<webCallAddress>的<address>替換為SBC的內部IP地址
	sed -i "/<webCallAddress>/{N;N;s/<address>.*/<address>${sbc_internal_ip}\<\/address\>/}" /home/sbc/cin/xmlwoods/sbc.xml
	# 使用sed命令將sbc.xml文件中的<msPublicIp>替換為SBC的內部IP地址
	sed -i "s/<msPublicIp privateIp=\"[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\"/<msPublicIp privateIp=\"${sbc_internal_ip}\"/" /home/sbc/cin/xmlwoods/sbc.xml
	echo "修改sbc.xml中的sbc內部IP完成"


## -------------------------------------------sbc外網-------------------------------------------------
# 提示用户输入sbc的外部地址
read -p "請输入sbc的外部地址: " sbc_external_ip
	# 檢查使用者是否輸入了IP地址並驗證是否為IPv4格式
	if [[ -z "$sbc_external_ip" || ! $sbc_external_ip =~ $ipv4_pattern ]]; then
		echo "未提供有效的IPv4格式內部IP地址。"
		exit 1
	fi
	echo "開始修改sbc.xml中的sbc外部IP"
	# 將sbc.xml文件中的<pubIpAddress>替換為SBC的外部IP地址
	sed -i "s/<pubIpAddress>.*<\/pubIpAddress>/<pubIpAddress>${sbc_external_ip}<\/pubIpAddress>/" /home/sbc/cin/xmlwoods/sbc.xml
	# 將sbc.xml文件中的<sbcRealm>替換為SBC的外部IP地址
	sed -i "s/<sbcRealm>.*<\/sbcRealm>/<sbcRealm>${sbc_external_ip}<\/sbcRealm>/" /home/sbc/cin/xmlwoods/sbc.xml
	# 將sbc.xml文件中的<pubIpMap>替換為SBC的外部IP地址
	sed -i "/<pubIpMap>/,/<\/pubIpMap>/{ /<pubIpAddress network=\"\" mask=\"\">/ s/\([0-9]\{1,3\}\.\)\{3\}[0-9]\{1,3\}/${sbc_external_ip}/ }" /home/sbc/cin/xmlwoods/sbc.xml
	# 將sbc.xml文件中的<msPublicIp>替換為SBC的外部IP地址
	sed -i "s/\(<msPublicIp privateIp=\"[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\" pubIpAddress=\"\)[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\">\([0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\)<\/msPublicIp>/\1${sbc_external_ip}\">${sbc_external_ip}<\/msPublicIp>/" /home/sbc/cin/xmlwoods/sbc.xml
	# sed "s/\(<msPublicIp privateIp=\"[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\" pubIpAddress=\"\)[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\">\([0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\)<\/msPublicIp>/\1${sbc_external_ip}\">\2${sbc_external_ip}<\/msPublicIp>/"
	echo "修改sbc.xml中的sbc外部IP完成"

## -------------------------------------------acd內網-------------------------------------------------
# 提示用户输入acd的內網地址
read -p "請输入acd的內網地址: " acd_internal_ip
# 檢查使用者是否輸入了IP地址並驗證是否為IPv4格式
	if [[ -z "$acd_internal_ip" || ! $acd_internal_ip =~ $ipv4_pattern ]]; then
		echo "未提供有效的IPv4格式內部IP地址。"
		exit 1
	fi
	echo "開始修改sbc.xml中的SIPX IP"
	# 將sbc.xml文件中的<ssIpAddress>替換為SIPX-acd的內部IP地址
	sed -i "s/<ssIpAddress>.*<\/ssIpAddress>/<ssIpAddress>${acd_internal_ip}<\/ssIpAddress>/" /home/sbc/cin/xmlwoods/sbc.xml
	# 將sbc.xml文件中的<ssRealm>替換為SIPX-acd的內部IP地址
	sed -i "s/<ssRealm>.*<\/ssRealm>/<ssRealm>${acd_internal_ip}<\/ssRealm>/" /home/sbc/cin/xmlwoods/sbc.xml
	# 將sbc.xml文件中的<ssNetwork>替換為SIPX-acd的內部IP地址
	sed -i "/<ssNetwork>/{N;N;s/<address>.*/<address>${acd_internal_ip}<\/address>/}" /home/sbc/cin/xmlwoods/sbc.xml
	#修改<sendAddress>為0
	echo "修改<sendAddress>為0"
	sed -i "s/<sendAddress>[0-9]<\/sendAddress>/<sendAddress>0<\/sendAddress>/g" /home/sbc/cin/xmlwoods/sbc.xml
	#修改<extSendAddress>為0
	echo "修改<extSendAddress>為0"
	sed -i "s/<extSendAddress>[0-9]<\/extSendAddress>/<extSendAddress>0<\/extSendAddress>/g" /home/sbc/cin/xmlwoods/sbc.xml
	#修改<extCallInLimit為3
	echo "修改<extCallInLimit為3"
	sed -i "s/<extCallInLimit>[0-9]<\/extCallInLimit>/<extCallInLimit>3<\/extCallInLimit>/g" /home/sbc/cin/xmlwoods/sbc.xml
	#修改<mediaRelay>為1
	echo "修改<mediaRelay>為1"
	sed -i "s/<mediaRelay>[0-9]<\/mediaRelay>/<mediaRelay>1<\/mediaRelay>/g" /home/sbc/cin/xmlwoods/sbc.xml
	#修改<pEarlyMedia>為1
	echo "修改<pEarlyMedia>為1"
	sed -i "s/<pEarlyMedia>[0-9]<\/pEarlyMedia>/<pEarlyMedia>1<\/pEarlyMedia>/g" /home/sbc/cin/xmlwoods/sbc.xml
	echo "修改sbc.xml中的SIPX IP完成"

## -------------------------------------------確認ms是否對外，並修改-------------------------------------------------
# 提示使用者是否直接對外
read -p "MS是否直接對外？（y/n）: " ms_is_direct_external

	# 檢查使用者是否輸入了有效的回答
	if [[ "$ms_is_direct_external" != "y" && "$ms_is_direct_external" != "n" ]]; then
		echo "無效的回答，請輸入“y”或“n”。"
		exit 1
	fi
	
	# 如果使用者選擇了“是”，則繼續詢問外部IP地址
	if [[ "$ms_is_direct_external" == "y" ]]; then
	  read -p "請輸入MS的外部IP地址: " ms_external_ip
	
	  # 檢查使用者是否輸入了IP地址並驗證是否為IPv4格式
	  if [[ -z "$ms_external_ip" || ! $ms_external_ip =~ $ipv4_pattern ]]; then
	    echo "未提供有效的IPv4格式外部IP地址。"
	    exit 1
	  fi
	
	echo "修改sbc.xml中的msPublicIp privateIp為MS的外部IP地址"
	  # 使用sed命令將sbc.xml文件中的<msPublicIp privateIp="MS外部IP"替換為MS的外部IP地址
	   sed -i "s/<msPublicIp privateIp=\"[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\"/<msPublicIp privateIp=\"${ms_external_ip}\"/g" /home/sbc/cin/xmlwoods/sbc.xml
	echo "修改sbc.xml中的msPublicIp privateIp為MS的外部IP地址完成"
	fi
	
	    echo "sbc.xml替换完成。"
	date +"%Y/%m/%d %H:%M:%S [SIPX-SBC] 修改sbc.xml" >> /home/setup/installed.txt
## =======================================修改sbx.xml檔案-end=========================================

## =======================================修改WebCall.xml檔案-start=======================================
	echo "修改acdweb的WebCall.xml"
	# 將acdweb的WebCall中的serviceAddress替換為SBC的內部IP地址
	sed -i "s/<serviceAddress>.*\:5030<\/serviceAddress>/<serviceAddress>${sbc_internal_ip}\:5030<\/serviceAddress>/g" /home/acdweb/cin/xmlwoods/WebCall.xml
	# 將acdweb的WebCall中的pubIpAddress替換為SBC的外部IP地址
	sed -i "s/<pubIpAddress>.*<\/pubIpAddress>/<pubIpAddress>${sbc_external_ip}<\/pubIpAddress>/g " /home/acdweb/cin/xmlwoods/WebCall.xml
	echo "修改acdweb的WebCall.xml完成"

	sed -i 's/ProxyPass "\/acd" "ws:\/\/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\:5068"/ProxyPass "\/acd" "ws:\/\/cinacd:5068"/g' /home/acdweb/apache/conf/extra/httpd-ssl.conf
	sed -i 's/ProxyPass "\/sbc" "ws:\/\/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\:5038"/ProxyPass "\/sbc" "ws:\/\/cinsbc:5038"/g' /home/acdweb/apache/conf/extra/httpd-ssl.conf
	sed -i 's/ProxyPass "\/monitor" "ws:\/\/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\:14816"/ProxyPass "\/monitor" "ws:\/\/cincti:14816"/g' /home/acdweb/apache/conf/extra/httpd-ssl.conf
	sed -i "s/BalancerMember ws\:\/\/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\:14812/BalancerMember ws\:\/\/cincti\:14812/p" /home/acdweb/apache/conf/extra/httpd-ssl.conf
	sed -i "s/BalancerMember ws\:\/\/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*\:14830/BalancerMember ws\:\/\/cincti\:14830/p" /home/acdweb/apache/conf/extra/httpd-ssl.conf

	date +"%Y/%m/%d %H:%M:%S [SIPX-acdweb] 修改WebCall.xml" >> /home/setup/installed.txt

## =======================================修改WebCall.xml檔案-end=========================================


## =======================================確認/etc/hosts-start=======================================
#取得sipxDB的位置
sipx_mysql_ip="$acd_internal_ip"
read -p "是否要修改 cinacd、cincti 的 IP為 $acd_internal_ip（y/n）？ " modify_cinacd

if [[ "$modify_cinacd" == "y" ]]; then
		# 替換 cinacd 的 IP
		if grep -q "cinacd" /etc/hosts; then
			sed -i "s/.* cinacd/$acd_internal_ip   cinacd/g" /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $acd_internal_ip cinacd " >> /home/setup/installed.txt
		else
			echo "找不到 cinacd 的解析，新增 cinacd 的解析。"
			echo "$acd_internal_ip   cinacd" >> /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $acd_internal_ip cinacd " >> /home/setup/installed.txt
		fi
		# 替換 cincti 的 IP
		if grep -q "cincti" /etc/hosts; then
			sed -i "s/.* cincti/$acd_internal_ip   cincti/g" /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $acd_internal_ip cincti " >> /home/setup/installed.txt
		else
			echo "找不到 cincti 的解析，新增 cincti 的解析。"
			echo "$acd_internal_ip   cincti" >> /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $acd_internal_ip cincti " >> /home/setup/installed.txt
		fi
	else
		read -p " 輸入acd的IP " new_acd_internal_ip
		if [[ $new_acd_internal_ip =~ $ipv4_pattern ]]; then
			if grep -q "cinacd" /etc/hosts; then
				sed -i "s/.* cinacd/$new_acd_internal_ip   cinacd/g" /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_acd_internal_ip cinacd " >> /home/setup/installed.txt
			else
				echo "找不到 cinacd 的解析，新增 cinacd 的解析。"
				echo "$new_acd_internal_ip   cinacd" >> /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_acd_internal_ip cinacd " >> /home/setup/installed.txt
			fi

		else
			echo "未提供有效的IPv4格式外部IP地址。"
		fi

		read -p " 輸入cti的IP " new_cti_internal_ip
                if [[ $new_cti_internal_ip =~ $ipv4_pattern ]]; then
			if grep -q "cincti" /etc/hosts; then
	                        sed -i "s/.* cincti/$new_cti_internal_ip   cincti/g" /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_cti_internal_ip cincti " >> /home/setup/installed.txt
			else
				echo "找不到 cincti 的解析，新增 cincti 的解析。"
                                echo "$new_cti_internal_ip   cinacd" >> /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_cti_internal_ip cincti " >> /home/setup/installed.txt
			fi
                else    
                        echo "未提供有效的IPv4格式外部IP地址。"
                fi


fi

# 檢查是否要修改 cinsdpdb 的 IP
read -p "是否要修改 cinsdpdb 的 IP 為 $sipx_mysql_ip（y/n）？ " modify_sipx_mysql

if [[ "$modify_sipx_mysql" == "y" ]]; then
		# 替換 cinsdpdb 的 IP
		if grep -q "cinsdpdb" /etc/hosts; then
			sed -i "s/.* cinsdpdb/$sipx_mysql_ip   cinsdpdb/g" /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $sipx_mysql_ip cinsdpdb " >> /home/setup/installed.txt
		else
			echo "找不到 cinsdpdb 的解析，新增 cinsdpdb 的解析。"
			echo "$sipx_mysql_ip   cinsdpdb" >> /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $sipx_mysql_ip cinsdpdb " >> /home/setup/installed.txt
		fi
	else
		read -p " 輸入sdpdb的IP " new_sdpdb_internal_ip
		if [[ $new_sdpdb_internal_ip =~ $ipv4_pattern ]]; then
			if grep -q "cinsdpdb" /etc/hosts; then
				sed -i "s/.* cinsdpdb/$new_sdpdb_internal_ip   cinsdpdb/g" /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_sdpdb_internal_ip cinsdpdb " >> /home/setup/installed.txt
			else
				echo "找不到 cinsdpdb 的解析，新增 cinsdpdb 的解析。"
				echo "$new_sdpdb_internal_ip   cinsdpdb" >> /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_sdpdb_internal_ip cinsdpdb " >> /home/setup/installed.txt
			fi

		else
			echo "未提供有效的IPv4格式外部IP地址。"
		fi
fi

# 檢查是否要修改 cinsbc 的 IP
read -p "是否要修改 cinsbc 的 IP 為 $sbc_internal_ip（y/n）？ " modify_sbc

if [[ "$modify_sbc" == "y" ]]; then
		# 替換 cinsbc 的 IP
		if grep -q "cinsbc" /etc/hosts; then
			sed -i "s/.* cinsbc/$sbc_internal_ip   cinsbc/g" /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $sbc_internal_ip cinsbc " >> /home/setup/installed.txt
		else
			echo "找不到 cinsbc 的解析，新增 cinsbc 的解析。"
			echo "$sbc_internal_ip   cinsbc" >> /etc/hosts
			echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $sbc_internal_ip cinsbc " >> /home/setup/installed.txt
		fi
	else
		read -p " 輸入sdpdb的IP " new_sbc_internal_ip
		if [[ $new_sbc_internal_ip =~ $ipv4_pattern ]]; then
			if grep -q "cinsbc" /etc/hosts; then
				sed -i "s/.* cinsbc/$new_sbc_internal_ip   cinsbc/g" /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_sbc_internal_ip cinsbc " >> /home/setup/installed.txt
			else
				echo "找不到 cinsbc 的解析，新增 cinsbc 的解析。"
				echo "$new_sbc_internal_ip   cinsbc" >> /etc/hosts
				echo "$(date +"%Y/%m/%d %H:%M:%S") 修改/etc/hosts $new_sbc_internal_ip cinsbc " >> /home/setup/installed.txt
			fi

		else
			echo "未提供有效的IPv4格式外部IP地址。"
		fi
fi
echo "完成修改。"


## =======================================確認/etc/hosts-end=========================================
